package db

import (
	"EXAM3/user_service/config"
	"context"
	"log"

	_ "github.com/lib/pq"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type MongoDB struct {
	Mclient *mongo.Client
}

func New(cfg config.Config) (*mongo.Client, error) {
	clientOptions := options.Client().ApplyURI("mongodb://127.0.0.1:27017")
	client, err := mongo.Connect(context.Background(), clientOptions)
	if err != nil {
		log.Fatal(err)
	}

	return client, nil
}

// func (p *Postgres) Close() {
// 	p.DB.Close()
// }
