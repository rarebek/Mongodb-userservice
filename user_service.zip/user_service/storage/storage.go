package storage

import (
	"EXAM3/user_service/pkg/logger"
	"EXAM3/user_service/storage/mongodb"
	"EXAM3/user_service/storage/repo"

	"go.mongodb.org/mongo-driver/mongo"
)

type IStorage interface {
	User() repo.UserStorageI
}

type storagePg struct {
	Mclient  *mongo.Client
	userRepo repo.UserStorageI
}

func NewStoragePg(Mclient *mongo.Client, log logger.Logger) *storagePg {
	return &storagePg{
		Mclient:  Mclient,
		userRepo: mongodb.NewUserRepo(Mclient, log),
	}
}

func (s storagePg) User() repo.UserStorageI {
	return s.userRepo
}
